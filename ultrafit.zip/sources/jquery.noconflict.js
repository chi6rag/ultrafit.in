jQuery.noConflict();
var $j = jQuery;