//03-06-2013 11:43:57
var journeycode='2425648C-D4CF-490D-8897-190ABC69051A';

var captureConfigUrl ='drs2.veinteractive.com/CaptureConfigService.asmx/CaptureConfig';

var chatServicesUrl ='rcs.veinteractive.com/ConversationService.asmx/';

(function() { 
 var ve = document.createElement('script'); 
 ve.type = 'text/javascript'; 
 ve.async = true; 
 ve.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'config1.veinteractive.com/tags/2425648C/D4CF/490D/8897/190ABC69051A/vecapture.js'; 
 var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(ve, s);

}) ();